# DegreeAuditPlusPlus
The site is hosted [here](http://ec2-52-14-173-245.us-east-2.compute.amazonaws.com:3000)
