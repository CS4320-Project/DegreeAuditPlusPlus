# DegreeAuditPlusPlus
### Sara Caponi, Jamie Flores, Daniel Jaegers, Derek Rogers, Erika Eckfeld, Kate Gardner, Sohaila Bakr

## How to Run Our Program As a Student
1. In order to run and use our program, open [**DegreeAuditPlusPlus**](HTTPS://TINYURL.COM/YC2JQ4SW)
2. Enter the **username: sbc436** and then the **password: 1234567**
3. Click Login and then the student info will be displayed.

## How to Run Our Program As a Advisor
1. In order to run and use our program, open [**DegreeAuditPlusPlus**](HTTPS://TINYURL.COM/YC2JQ4SW)
2. Enter the **username: nbalser** and then the **password: 1234567**
3. Click login and then input **student number: 14261685** under the student search section
3. Click Search and then the student info will be displayed. 
