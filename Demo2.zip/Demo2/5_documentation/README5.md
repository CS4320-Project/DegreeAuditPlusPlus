## Key Differences between Demo 1 and Demo 2
* Added more students and more classes to the database
* Animated doughnut chart that depicts degree progress
	* Shows the student's Past Courses, Current Courses, and Outstanding Courses
* GPA Calculator
	* Considers a student's previous courses and grades
	* Projects a student's GPA based on anticipated grades for the current semester
	* Dynamically adds the courses that the student is currently enrolled in
	* Dynamically adds the student's previous GPA
* Updated and improved User Interface throughout the application
<!--stackedit_data:
eyJoaXN0b3J5IjpbMTUyNjM0NDQ4MiwtNzkwMjUzNjYsNzMwOT
k4MTE2XX0=
-->