# DegreeAuditPlusPlus
##### Sara Caponi, Jamie Flores, Daniel Jaegers, Derek Rogers, Erika Eckfeld, Kate Gardner, Sohaila Bakr

The site is hosted [here](http://ec2-52-14-173-245.us-east-2.compute.amazonaws.com:3000)


## How to Run Our Program As a Student

1. In order to run and use our program, open [****DegreeAuditPlusPlus****](HTTPS://TINYURL.COM/YC2JQ4SW)

2. Enter the ****username: sbc436**** and then the ****password: abc123****

3. Click Login and then the student info will be displayed.

  

## How to Run Our Program As a Advisor

1. In order to run and use our program, open [****DegreeAuditPlusPlus****](HTTPS://TINYURL.COM/YC2JQ4SW)

2. Enter the ****username: balsern**** and then the ****password: tigers1****

3. Click login and then input ****pawPrint: sbc436 or pdokdf**** under the student search section

34. Click Search and then the student info will be displayed. 

## How to Run Our Program Locally

1.  Clone our repository with 
```
git clone https://github.com/CS4320-Project/DegreeAuditPlusPlus.git
```

### Starting the development environment

Make sure all the dependencies are installed by running

```
npm i
cd backend
npm i
cd ..
```

If you encounter errors, you may need to remove the `node_modules` folders with

```
rm -r node_modules
rm -r backend/node_modules
```

Then freshly run the `npm i` commands.

Once everything is installed, start the backend by running
```
node backend/server.js
```

Keep this terminal window open! Open a new window and start the React app with

```
npm start
```
## Project Files
#### App.js
This component contains a JSON object for the data of our demo. It has the student information like: PawPrint, name, degree program, etc…. It also has a JSON array of all the courses that the student has taken. This component is passed to the UserInfo component so that it uses it to show the data of the student.

#### Chart.js
The component contains all of the JavaScript involved in creating our doughnut chart on the home page. This Doughnut chart depicts the progress of your degree program. It has three different categories: Completed Hours, Currently Enrolled Hours, and Remaining Hours. This component pulls this information from a parent component.

#### Footer.js 
This component creates the footer for DegreeAudit++. The footer is displayed on every page of the web application. The footer contains the copyright symbol and all team members names.

#### GPACalculator.js

The component contains all of the JavaScript involved in creating and displaying our GPACalculator. This calculator takes 4 different types of inputs: course hours, anticipated grade for the respective course, previous GPA, and previous GPA hours attempted. Using these numbers and the University of Missuori’s grade scale, the component calculates and displays: Total points, Total hours, Semester GPA, Overall GPA.

  

#### Header.js

The header component has the Nav bar of our web app that appears on all the pages. It has the title of the app on the left corner, home, and login button on the right corner. The login button changes dynamically to logout when the user clicks it.

  

#### Home.js

Home is the component that renders the other components that are viable on our home page. It renders the userInfo and Tab components which together comprise the majority of our system. It has an array of users as it state which it can then pass to other components to use.

  

#### LoginForm.js

This component is incharge of validating if the inputted user name and password are correct and determining what type of user the user is, student or advisor. It makes a request to the back end to check if the information matches our records and then sets the state and props of the component with the correct information. If the entered data is not correct, the user will be presented with a error. If the entered data is correct they will be directed to the next appropriate page which is determined by the type of user.

  

#### Main.js

This component displays the correct screen to the user based on the information provided. It also renders information to be displayed on the desired page. It does this by implementing a switch statement with the correct routes in the switch.

  

#### StudentSearch.js

This component is comprised of a component with a search bar and button. It allows the user, if an advisor, to search for students by entering the student number. This class will produce an error message if the number entered is not a current student in the database. It then sends this number to the user info and app class to render the correct information to the user.

  

#### Tab.js

This component composed of three different tabs: Past Classes, Current Classes, and Outstanding Classes. To navigate between these options, click the tabs. The user is able to swipe through three different tabs that correspond to the table views being shown.

  

#### Table.js

This component gathers information from the student’s class history and what they need to complete their degree. The tabs relate the to view of the table which indicate whether the classes shown are past classes taken, current classes, or classes that are outstanding. The table is sortable based on certain criteria such as class name, grades, credit hours, etc.

  

#### UserInfo.js

This component renders the students information onto the homepage. It is in this class that we will implement the algorithms to calculate the students expected graduation date, and their gpa.

#### Server.js
This file handles all of the database queries. It receives requests from the front end and uses Mongoose to retrieve the appropriate data from MongoDB
<!--stackedit_data:
eyJoaXN0b3J5IjpbLTE2OTIxNjI4ODUsLTM4MjYwNDc2M119
-->